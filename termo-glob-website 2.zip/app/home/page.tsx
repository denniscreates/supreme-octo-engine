"use client"

import { useEffect } from "react"
import { useLanguage } from "@/components/language-provider"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, ArrowRight, Award, Users, BarChart3 } from "lucide-react"
import CounterSection from "@/components/counter-section"
import TestimonialSection from "@/components/testimonial-section"

export default function Home() {
  const { t } = useLanguage()

  // Force scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section with Image Background */}
      <section className="relative h-[80vh] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image src="/images/hvac-hero.jpg" alt="HVAC Systems" fill className="object-cover" priority />
          <div className="absolute inset-0 bg-black/60" />
        </div>

        <div className="container relative z-10 flex flex-col items-center justify-center h-full text-center text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">{t("heroTitle")}</h1>
          <p className="text-xl md:text-2xl max-w-3xl mb-8">{t("heroSubtitle")}</p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg" className="bg-red-600 hover:bg-red-700">
              <Link href="/contact">{t("contactUs")}</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              <Link href="/services">{t("ourServices")}</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t("ourServices")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("servicesSubtitle")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-red-600"
                  >
                    <path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z" />
                    <path d="M17 18h1" />
                    <path d="M12 18h1" />
                    <path d="M7 18h1" />
                  </svg>
                </div>
                <CardTitle>{t("hvacProducts")}</CardTitle>
                <CardDescription>{t("hvacProductsDesc")}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("hvacProductFeature1")}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("hvacProductFeature2")}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("hvacProductFeature3")}</span>
                  </li>
                </ul>
                <Button asChild variant="ghost" className="mt-6 w-full text-red-600 hover:bg-gray-100 font-medium">
                  <Link href="/services" className="flex items-center justify-center gap-1">
                    {t("learnMore")} <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-blue-600"
                  >
                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                    <path d="M3.29 7 12 12l8.71-5" />
                    <path d="M12 22V12" />
                  </svg>
                </div>
                <CardTitle>{t("hvacInstallation")}</CardTitle>
                <CardDescription>{t("hvacInstallationDesc")}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("hvacInstallFeature1")}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("hvacInstallFeature2")}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("hvacInstallFeature3")}</span>
                  </li>
                </ul>
                <Button asChild variant="ghost" className="mt-6 w-full text-red-600 hover:bg-gray-100 font-medium">
                  <Link href="/services" className="flex items-center justify-center gap-1">
                    {t("learnMore")} <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-green-600"
                  >
                    <path d="M2 12h20" />
                    <path d="M2 12v8a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-8" />
                    <path d="M2 12v-2a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v2" />
                    <path d="M6 12v-2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2" />
                  </svg>
                </div>
                <CardTitle>{t("cadProjects")}</CardTitle>
                <CardDescription>{t("cadProjectsDesc")}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("cadFeature1")}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("cadFeature2")}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>{t("cadFeature3")}</span>
                  </li>
                </ul>
                <Button asChild variant="ghost" className="mt-6 w-full text-red-600 hover:bg-gray-100 font-medium">
                  <Link href="/services" className="flex items-center justify-center gap-1">
                    {t("learnMore")} <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">{t("aboutTitle")}</h2>
              <p className="text-gray-600 mb-6">{t("aboutDescription1")}</p>
              <p className="text-gray-600 mb-8">{t("aboutDescription2")}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                <div className="flex items-start gap-3">
                  <div className="rounded-full bg-red-100 p-2 mt-1">
                    <Award className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{t("qualityService")}</h3>
                    <p className="text-gray-600 text-sm">{t("qualityServiceDesc")}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="rounded-full bg-blue-100 p-2 mt-1">
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{t("expertTeam")}</h3>
                    <p className="text-gray-600 text-sm">{t("expertTeamDesc")}</p>
                  </div>
                </div>
              </div>

              <Button asChild className="bg-red-600 hover:bg-red-700 text-white">
                <Link href="/about">{t("readMoreAboutUs")}</Link>
              </Button>
            </div>

            <div className="relative">
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
                <Image src="/images/hvac-industrial.jpeg" alt="Termo Glob HVAC Systems" fill className="object-cover" />
              </div>
              {/* Added back the contact box with red text */}
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="h-5 w-5 text-red-600" />
                  <h3 className="font-bold text-red-600">{t("experience")}</h3>
                </div>
                <p className="text-3xl font-bold text-red-600">5000+</p>
                <p className="text-red-600 font-medium">{t("completedProjects")}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Counter Section */}
      <CounterSection />

      {/* Testimonials */}
      <TestimonialSection />

      {/* CTA Section */}
      <section className="py-20 bg-red-600 text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">{t("ctaTitle")}</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">{t("ctaDescription")}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-red-600 font-bold"
            >
              <Link href="/contact">{t("contactUs")}</Link>
            </Button>
            <Button asChild size="lg" className="bg-white text-red-600 hover:bg-gray-100 font-bold">
              <Link href="/careers">{t("joinOurTeam")}</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
