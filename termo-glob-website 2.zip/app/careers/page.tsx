"use client"

import { useLanguage } from "@/components/language-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Briefcase, MapPin, Clock } from "lucide-react"
import JobApplicationForm from "@/components/job-application-form"

export default function CareersPage() {
  const { t } = useLanguage()

  const jobOpenings = [
    {
      id: 1,
      title: t("hvacTechnician"),
      location: t("pristina"),
      type: t("fullTime"),
      description: t("hvacTechnicianDesc"),
      requirements: [t("hvacTechReq1"), t("hvacTechReq2"), t("hvacTechReq3"), t("hvacTechReq4")],
    },
    {
      id: 2,
      title: t("cadDesigner"),
      location: t("pristina"),
      type: t("fullTime"),
      description: t("cadDesignerDesc"),
      requirements: [t("cadDesignerReq1"), t("cadDesignerReq2"), t("cadDesignerReq3"), t("cadDesignerReq4")],
    },
    {
      id: 3,
      title: t("salesRepresentative"),
      location: t("pristina"),
      type: t("fullTime"),
      description: t("salesRepDesc"),
      requirements: [t("salesRepReq1"), t("salesRepReq2"), t("salesRepReq3"), t("salesRepReq4")],
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="container text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t("careersTitle")}</h1>
          <p className="text-xl max-w-2xl mx-auto">{t("careersSubtitle")}</p>
        </div>
      </section>

      {/* Why Join Us */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t("whyJoinUs")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("whyJoinUsDesc")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-none shadow-lg">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-red-600"
                  >
                    <path d="M12 20h9" />
                    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
                  </svg>
                </div>
                <CardTitle>{t("professionalGrowth")}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600">{t("professionalGrowthDesc")}</p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-blue-600"
                  >
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </div>
                <CardTitle>{t("teamwork")}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600">{t("teamworkDesc")}</p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="text-center pb-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-green-600"
                  >
                    <path d="M20.2 7.8l-7.7 7.7-4-4-5.7 5.7" />
                    <path d="M15 7h6v6" />
                  </svg>
                </div>
                <CardTitle>{t("careerAdvancement")}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600">{t("careerAdvancementDesc")}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Current Openings */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t("currentOpenings")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("currentOpeningsDesc")}</p>
          </div>

          <div className="space-y-8">
            {jobOpenings.map((job) => (
              <Card key={job.id} className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="md:col-span-3">
                      <h3 className="text-xl font-bold mb-2">{job.title}</h3>
                      <div className="flex flex-wrap gap-4 mb-4">
                        <div className="flex items-center text-gray-600">
                          <MapPin className="h-4 w-4 mr-1" />
                          {job.location}
                        </div>
                        <div className="flex items-center text-gray-600">
                          <Clock className="h-4 w-4 mr-1" />
                          {job.type}
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4">{job.description}</p>
                      <div className="mb-4">
                        <h4 className="font-semibold mb-2">{t("requirements")}:</h4>
                        <ul className="list-disc pl-5 space-y-1">
                          {job.requirements.map((req, index) => (
                            <li key={index} className="text-gray-600">
                              {req}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    <div className="flex items-center justify-center md:justify-end">
                      <Button asChild>
                        <a href="#application-form" className="flex items-center gap-2">
                          <Briefcase className="h-4 w-4" />
                          {t("applyNow")}
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section id="application-form" className="py-20 bg-gray-50">
        <div className="container max-w-3xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">{t("applyForPosition")}</h2>
            <p className="text-gray-600">{t("applyFormDesc")}</p>
          </div>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <JobApplicationForm jobOpenings={jobOpenings} />
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
