"use client"

import { useEffect } from "react"
import { useLanguage } from "@/components/language-provider"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import CounterSection from "@/components/counter-section"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AboutPage() {
  const { t } = useLanguage()

  // Force scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const values = [
    {
      title: t("qualityService"),
      description: t("qualityServiceDesc"),
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-red-600"
        >
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
          <path d="m9 12 2 2 4-4" />
        </svg>
      ),
    },
    {
      title: t("expertTeam"),
      description: t("expertTeamDesc"),
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-blue-600"
        >
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      ),
    },
    {
      title: t("innovativeSolutions"),
      description: t("innovativeSolutionsDesc"),
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-green-600"
        >
          <path d="M2 12h20" />
          <path d="M12 2v20" />
          <path d="m4.93 4.93 14.14 14.14" />
          <path d="m19.07 4.93-14.14 14.14" />
        </svg>
      ),
    },
  ]

  const milestones = [
    {
      year: "2010",
      title: t("companyFounded"),
      description: t("companyFoundedDesc"),
    },
    {
      year: "2013",
      title: t("expansionMilestone"),
      description: t("expansionMilestoneDesc"),
    },
    {
      year: "2016",
      title: t("certificationMilestone"),
      description: t("certificationMilestoneDesc"),
    },
    {
      year: "2020",
      title: t("digitalTransformation"),
      description: t("digitalTransformationDesc"),
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-20">
        <div className="container text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t("aboutTitle")}</h1>
          <p className="text-xl max-w-2xl mx-auto">{t("aboutSubtitle")}</p>
        </div>
      </section>

      {/* About Content */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <h2 className="text-3xl font-bold mb-6">{t("ourStory")}</h2>
              <p className="text-gray-600 mb-6">{t("aboutDescription1")}</p>
              <p className="text-gray-600">{t("aboutDescription2")}</p>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
              <Image src="/images/hvac-industrial.jpeg" alt="Termo Glob Team" fill className="object-cover" />
            </div>
          </div>

          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">{t("ourValues")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("ourValuesDesc")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            {values.map((value, index) => (
              <Card key={index} className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                      {value.icon}
                    </div>
                    <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                    <p className="text-gray-600">{value.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">{t("ourJourney")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("ourJourneyDesc")}</p>
          </div>

          <div className="relative">
            {/* Timeline */}
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gray-200"></div>

            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <div key={index} className="relative">
                  <div
                    className={`flex items-center ${
                      index % 2 === 0 ? "flex-row md:flex-row-reverse" : "flex-row"
                    } gap-8`}
                  >
                    <div className="md:w-1/2"></div>
                    <div className="absolute left-1/2 transform -translate-x-1/2 flex items-center justify-center w-8 h-8 rounded-full bg-red-600 text-white z-10">
                      <span className="text-sm font-bold">{milestone.year}</span>
                    </div>
                    <div className="md:w-1/2">
                      <Card className="border-none shadow-lg">
                        <CardContent className="p-6">
                          <h3 className="text-xl font-bold mb-2">{milestone.title}</h3>
                          <p className="text-gray-600">{milestone.description}</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Counter Section */}
      <CounterSection />

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">{t("ourTeam")}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("ourTeamDesc")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-none shadow-lg overflow-hidden">
              <div className="relative h-64">
                <Image src="/placeholder.svg?height=300&width=400" alt="Team Member" fill className="object-cover" />
              </div>
              <CardContent className="p-6 text-center">
                <h3 className="text-xl font-bold mb-1">{t("teamMember1")}</h3>
                <p className="text-gray-500 mb-4">{t("teamMember1Position")}</p>
                <p className="text-gray-600">{t("teamMember1Desc")}</p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg overflow-hidden">
              <div className="relative h-64">
                <Image src="/placeholder.svg?height=300&width=400" alt="Team Member" fill className="object-cover" />
              </div>
              <CardContent className="p-6 text-center">
                <h3 className="text-xl font-bold mb-1">{t("teamMember2")}</h3>
                <p className="text-gray-500 mb-4">{t("teamMember2Position")}</p>
                <p className="text-gray-600">{t("teamMember2Desc")}</p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg overflow-hidden">
              <div className="relative h-64">
                <Image src="/placeholder.svg?height=300&width=400" alt="Team Member" fill className="object-cover" />
              </div>
              <CardContent className="p-6 text-center">
                <h3 className="text-xl font-bold mb-1">{t("teamMember3")}</h3>
                <p className="text-gray-500 mb-4">{t("teamMember3Position")}</p>
                <p className="text-gray-600">{t("teamMember3Desc")}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Add a proper button at the bottom of the page for better navigation */}
      <section className="py-16 bg-red-600 text-white">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-4">{t("workWithUs")}</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">{t("contactUsToday")}</p>
          <Button asChild size="lg" className="bg-white text-red-600 hover:bg-gray-100 font-bold">
            <Link href="/contact">{t("contactUs")}</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
