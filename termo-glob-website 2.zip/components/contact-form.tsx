"use client"

import type React from "react"

import { useState } from "react"
import { useLanguage } from "./language-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import ReCAPTCHA from "react-google-recaptcha"

export default function ContactForm() {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [captchaValue, setCaptchaValue] = useState<string | null>(null)

  const countryCodes = [
    { code: "+383", country: "Kosovo" },
    { code: "+355", country: "Albania" },
    { code: "+389", country: "North Macedonia" },
    { code: "+381", country: "Serbia" },
    { code: "+382", country: "Montenegro" },
    { code: "+49", country: "Germany" },
    { code: "+31", country: "Netherlands" },
    { code: "+41", country: "Switzerland" },
    { code: "+43", country: "Austria" },
    { code: "+32", country: "Belgium" },
  ]

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!captchaValue) {
      toast({
        title: t("captchaRequired"),
        description: t("pleaseCompleteCaptcha"),
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    const formData = new FormData(e.currentTarget)

    try {
      // This would normally send to your Google Form
      const googleFormURL =
        "https://docs.google.com/forms/d/e/1FAIpQLScU0of88ZlW7baAHyFm6NmDROSBSwren_XIX2Ki57MU3y999g/formResponse"

      // In a real implementation, you would map your form fields to Google Form fields
      // For now, we'll simulate a successful submission
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: t("messageSent"),
        description: t("thankYouMessage"),
      })

      // Reset form
      ;(e.target as HTMLFormElement).reset()
      setCaptchaValue(null)
    } catch (error) {
      toast({
        title: t("errorOccurred"),
        description: t("pleaseTryAgain"),
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="name">{t("fullName")} *</Label>
          <Input id="name" name="name" required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">{t("emailAddress")} *</Label>
          <Input id="email" name="email" type="email" required />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="phone">{t("phoneNumber")}</Label>
          <div className="flex">
            <Select name="countryCode">
              <SelectTrigger className="w-[110px] rounded-r-none border-r-0">
                <SelectValue placeholder="+383" defaultValue="+383" />
              </SelectTrigger>
              <SelectContent>
                {countryCodes.map((country) => (
                  <SelectItem key={country.code} value={country.code}>
                    {country.code} ({country.country})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input id="phone" name="phone" type="tel" className="rounded-l-none" />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="subject">{t("subject")} *</Label>
          <Input id="subject" name="subject" required />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">{t("message")} *</Label>
        <Textarea id="message" name="message" rows={5} required />
      </div>

      <div className="flex justify-center my-6">
        <ReCAPTCHA
          sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI" // This is a test key
          onChange={(value) => setCaptchaValue(value)}
        />
      </div>

      <Button type="submit" className="w-full" disabled={isSubmitting || !captchaValue}>
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {t("sending")}
          </>
        ) : (
          t("sendMessage")
        )}
      </Button>
    </form>
  )
}
