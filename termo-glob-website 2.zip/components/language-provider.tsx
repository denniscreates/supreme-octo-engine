"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"

type Language = "en" | "sq" | "de" | "nl"

type LanguageContextType = {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")
  const [translations, setTranslations] = useState<Record<string, Record<string, string>>>({})
  const pathname = usePathname()
  const router = useRouter()

  useEffect(() => {
    // Load translations
    const loadTranslations = async () => {
      const translations = {
        en: await import("@/translations/en.json").then((m) => m.default),
        sq: await import("@/translations/sq.json").then((m) => m.default),
        de: await import("@/translations/de.json").then((m) => m.default),
        nl: await import("@/translations/nl.json").then((m) => m.default),
      }
      setTranslations(translations)
    }

    loadTranslations()

    // Check browser language or localStorage
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && ["en", "sq", "de", "nl"].includes(savedLanguage)) {
      setLanguage(savedLanguage)
    } else {
      const browserLang = navigator.language.split("-")[0]
      if (browserLang === "sq" || browserLang === "de" || browserLang === "nl") {
        setLanguage(browserLang as Language)
      }
    }
  }, [])

  const t = (key: string): string => {
    if (!translations[language]) return key
    return translations[language][key] || translations.en[key] || key
  }

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem("language", lang)
    // Force a refresh to apply language changes across all pages
    router.refresh()
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
